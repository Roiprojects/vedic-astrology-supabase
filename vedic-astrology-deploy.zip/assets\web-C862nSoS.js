import{T as n}from"./index-nlATDn-P.js";import"./motion-DYXvqOvT.js";import"./react-PRy6S6qf.js";class t extends n{async show(e){}async hide(e){}}export{t as SplashScreenWeb};
