import { createClient, type SupabaseClient } from "@supabase/supabase-js";

declare global {
  var __supaClient: SupabaseClient | undefined;
}

function createSupaClient(): SupabaseClient {
  const url = process.env.SUPABASE_URL || "";
  const key = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || "";
  if (!url || !key) {
    throw new Error("SUPABASE_URL and SUPABASE_ANON_KEY must be set");
  }
  return createClient(url, key);
}

export const supa: SupabaseClient = globalThis.__supaClient ?? createSupaClient();

if (process.env.NODE_ENV !== "production") {
  globalThis.__supaClient = supa;
}

type EqTuple = [string, any];
type OrderOpt = { column: string; ascending?: boolean };

function applyFilters<T>(
  q: ReturnType<SupabaseClient["from"]>,
  opts?: {
    select?: string;
    eq?: EqTuple[];
    in?: [string, any[]];
    order?: OrderOpt | OrderOpt[];
    limit?: number;
    data?: any;
    onConflict?: string;
  }
): ReturnType<SupabaseClient["from"]> {
  if (opts?.eq) {
    for (const [col, val] of opts.eq) q = q.eq(col, val);
  }
  if (opts?.in) q = q.in(opts.in[0], opts.in[1]);
  if (opts?.data) q = q.insert(opts.data);
  if (opts?.order) {
    const orders = Array.isArray(opts.order) ? opts.order : [opts.order];
    for (const o of orders) q = q.order(o.column, { ascending: o.ascending ?? true });
  }
  if (opts?.limit) q = q.limit(opts.limit);
  if (opts?.onConflict) q = q.onConflict(opts.onConflict);
  return q;
}

export async function query<T = any>(
  table: string,
  method: "select" | "insert" | "upsert" | "update" | "delete",
  options?: {
    select?: string;
    eq?: EqTuple[];
    in?: [string, any[]];
    order?: OrderOpt | OrderOpt[];
    limit?: number;
    data?: any;
    onConflict?: string;
  }
): Promise<{ rows: T[]; rowCount: number; error: any }> {
  let q = supa.from(table);
  const sel = options?.select || "*";

  switch (method) {
    case "select":
      q = applyFilters(q, options);
      q = q.select(sel, { count: "exact" } as any);
      break;
    case "insert":
      q = applyFilters(q, options);
      q = q.select(sel, { count: "exact" } as any);
      break;
    case "upsert":
      q = q.upsert(options?.data || {}, { onConflict: options?.onConflict || "" });
      q = q.select(sel, { count: "exact" } as any);
      break;
    case "update": {
      q = q.update(options?.data || "");
      if (options?.eq) {
        for (const [col, val] of options.eq) q = q.eq(col, val);
      }
      q = q.select(sel, { count: "exact" } as any);
      break;
    }
    case "delete":
      q = applyFilters(q, options);
      q = q.delete();
      break;
  }

  const result = await q;
  const error = result.error;

  if (error) {
    const err = new Error(error.message || "DB error") as any;
    err.code = error.code;
    err.details = error.details;
    err.hint = error.hint;
    throw err;
  }

  const count = typeof result.count === "number" ? result.count : 0;
  const rows = (result.data as T[]) || [];
  return { rows, rowCount: count, error: null };
}

export async function testDatabaseConnection(): Promise<{
  success: boolean;
  database?: string;
  serverTime?: string;
  error?: string;
}> {
  try {
    const { error } = supa.from("settings").select("key").limit(1);
    if (error) throw error;
    return {
      success: true,
      database: new URL(supa.supabaseUrl).hostname,
      serverTime: new Date().toISOString(),
    };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export const pool = { supa, query, testDatabaseConnection } as const;
export default pool;
